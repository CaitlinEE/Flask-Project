from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

conn = sqlite3.connect('ACTUAL_DATABASE.db')
c = conn.cursor()



@app.route('/order', methods=['GET', 'POST'])
def order():
   allowed_items = ['Chicken Burger', 'Cheesy Beef Burger', 'Barbecue Bacon Burger', 'Black Bean Burger', 'Hot & Spicy Burger']
   if request.method == 'POST':
        customer_name = request.form['customer_name']
        item = request.form['item']
        quantity = request.form['quantity']

        if item not in allowed_items:
            error_message = f"Error: '{item}' is not a valid item. Please select from {', '.join(allowed_items)}."
            return render_template('order.html', error=error_message)

        conn = sqlite3.connect('ACTUAL_DATABASE.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO orders (customer_name, item, quantity) VALUES (?, ?, ?)",
                       (customer_name, item, quantity))
        conn.commit()
        conn.close()
        return redirect(url_for('orders'))
   return render_template('order.html')

@app.route('/orders', methods=['GET', 'POST'])
def orders():
    #if request.method == 'GET':
     conn = sqlite3.connect('ACTUAL_DATABASE.db')
     c = conn.cursor()
     c.execute("SELECT * FROM orders")
     all_orders = c.fetchall()
     conn.close()
     return render_template('orders.html', orders=all_orders)
    #return render_template('/review')
    

@app.route('/review', methods=['GET', 'POST'])
def review():
 allowed_items = ['Chicken Burger', 'Cheesy Beef Burger', 'Barbecue Bacon Burger', 'Black Bean Burger', 'Hot & Spicy Burger']

 if request.method == 'POST':
       cus_name = request.form['cus_name']
       item_ordered = request.form['item_ordered']
       date_ordered = request.form['date_ordered']
       reviewed = request.form['reviewed']

       if item_ordered not in allowed_items:
            error_message = f"Error: '{item_ordered}' is not a valid item. Please select from {', '.join(allowed_items)}."
            return render_template('review.html', error=error_message)

       conn = sqlite3.connect('ACTUAL_DATABASE.db')
       cursor = conn.cursor()
       cursor.execute("INSERT INTO reviews (cus_name, item_ordered, date_ordered, reviewed) VALUES (?, ?, ?, ?)",
                       (cus_name, item_ordered, date_ordered, reviewed))
       conn.commit()
       conn.close()
       return redirect(url_for('reviews'))
 

 return render_template('review.html')
    

@app.route('/reviews', methods=['GET', 'POST'])
def reviews():
    #if request.method == 'GET':
     conn = sqlite3.connect('ACTUAL_DATABASE.db')
     c = conn.cursor()
     c.execute("SELECT * FROM reviews")
     all_reviews = c.fetchall()
     conn.close()
     return render_template('reviews.html', reviews=all_reviews)


     


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/navbar')
def next():
    return render_template('navbar.html')



if __name__ == '__main__':
  app.run(debug=True)

